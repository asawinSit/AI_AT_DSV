//Asawin Sitthi assi7068
//Chris Pilegård chpi8651
class Team {

  Tank[] tanks = new Tank[3];
  int id; // team red 0, team blue 1.
  int tank_size;
  PVector tank0_startpos = new PVector();
  PVector tank1_startpos = new PVector();
  PVector tank2_startpos = new PVector();

  float homebase_x;
  float homebase_y;
  float homebase_width = 150;
  float homebase_height = 350;

  NodeType homeBaseNodeType;
  color team_color;

  RadioSystem radioSystem;

  GameManager gameManager;

  Team (GameManager gameManager, int team_id, int tank_size, color c, NodeType n,
    PVector tank0_startpos, int tank0_id,
    PVector tank1_startpos, int tank1_id,
    PVector tank2_startpos, int tank2_id)
  {
    this.gameManager = gameManager;
    this.id = team_id;
    this.tank_size = tank_size;
    this.team_color = c;
    this.homeBaseNodeType = n;
    this.tank0_startpos.set(tank0_startpos);
    this.tank1_startpos.set(tank1_startpos);
    this.tank2_startpos.set(tank2_startpos);

    tanks[0] = new Tank(tank0_id, this, tank0_startpos, tank_size, c);
    tanks[1] = new Tank(tank1_id, this, tank1_startpos, tank_size, c);
    tanks[2] = new Tank(tank2_id, this, tank2_startpos, tank_size, c);


    if (this.id==0) {
      this.homebase_x = 0;
      this.homebase_y = 0;
    } else if (this.id==1) {
      this.homebase_x = width - 151;
      this.homebase_y = height - 351;
    }

    radioSystem = new RadioSystem(this);
  }

  int getId() {
    return this.id;
  }

  color getColor() {
    return this.team_color;
  }

  void updateLogic() {
    for (Tank tank : tanks) {
      tank.update();
    }
    radioSystem.update();
  }

  void onTankDied()
  {

    if (isAllTanksDead())
    {
      println("Team eliminated");
      gameManager.setGamOver(true);
    }
  }

  void onTankDisable(Tank tank)
  {
    gameManager.grid.markObstacle(tank.position(), tank.radius, 15);
  }

  boolean isAllTanksDead()
  {
    for (Tank t : tanks)
    {
      if ( !t.isDead())
        return false;
    }
    return true;
  }

  void displayHomeBaseTeam() {
    strokeWeight(1);
    //fill(204, 50, 50, 15);
    fill(this.team_color, 15);
    //rect(0, 0, 150, 350);
    rect(this.homebase_x, this.homebase_y, this.homebase_width, this.homebase_height);
  }

  void displayTanks() {
    for (Tank tank : tanks) {
      tank.display();
    }
  }
}
