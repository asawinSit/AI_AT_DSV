//Asawin Sitthi assi7068
//Chris Pilegård chpi8651

enum TankState {
  SEARCH, REPORT, STOP
}

enum Nav_Imp {
  LRTA, DEFAULT
}

class Tank extends Sprite {

  // Physics
  PVector startpos;
  PVector acceleration;
  PVector velocity;
  float speed = 0;
  float maxSpeed = 3.0;
  float turnStep = 0.5;

  float maxForce = 0.1;

  // Identity
  int tank_id;
  Team team;
  color col;
  boolean active;

  // State
  TankState tankState;

  Nav_Imp nav_Imp;

  // Sensor
  WorldSensor worldSensor;
  int cellSize; // Should the tank know this? Argument, tank team decision for accurate search.
  float   rayLength  = 75;
  float   rayWidth;

  // own knowledge graph
  HashMap<String, Node> knownMap = new HashMap<String, Node>();
  LRTA LRTA_Nav = new LRTA();

  // Navigation
  Node currentNode;
  Node lastNode;
  Node targetNode;
  Node goalNode;
  ArrayList<Node> path = new ArrayList<Node>();

  int reportWaitFrames = 0;
  static final int REPORT_WAIT_DURATION = 180; // 3 seconds at 60fps

  Tank(int id, Team team, PVector _startpos, float _size, color _col) {
    this.tank_id      = id;
    this.diameter     = _size;
    this.radius       = diameter/2;
    this.col          = _col;
    this.team         = team;
    this.startpos     = _startpos.copy();
    this.position     = _startpos.copy();
    this.velocity     = new PVector(0, 0);
    this.acceleration = new PVector(0, 0);

    nav_Imp = Nav_Imp.DEFAULT;

    rayWidth   = radius /2;
  }

  void addHomeBase(ArrayList<Node> homeBase) {
    for (Node n : homeBase) {
      String key = getPositionKey(n.col, n.row);
      if (!knownMap.containsKey(key)) {
        n.exploredState = ExploredState.VISIBLE;
        n.distanceFromBase = 0;
        knownMap.put(key, n);
      }
    }
    for (Node n : homeBase) wireNeighbours(n);
    currentNode = nearestKnownNode(position);
    lastNode = currentNode;
    currentNode.exploredState = ExploredState.VISITED;
    perceiveNeighbours();
  }

  void update() {
    if (active != true) return;

    int col = worldToCol(position.x);
    int row = worldToRow(position.y);
    String key = getPositionKey(col, row);
    Node node = knownMap.containsKey(key) ? knownMap.get(key) : null;

    if (node != null && node != lastNode) {
      lastNode = currentNode;
      currentNode = node;
      currentNode.exploredState = ExploredState.VISITED;
      perceiveNeighbours();
    }
    if (enemyInSight()) {
      println("Enemy detected");
    }

    switch (tankState) {
    case SEARCH:
      if (worldSensor.isMoreThanHalfInsideABase(69, this) && enemyInSight()) {
        path.clear();
        reportWaitFrames = 0;
        tankState = TankState.REPORT;
      } else {
        search();
      }
      break;
    case REPORT:
      returnToBase();
      break;
    case STOP:
      stopMoving();
      break;
    }
    updatePosition();
  }

  void search() {
    Node nextNode = null;
    if (nav_Imp == Nav_Imp.LRTA)
    {
      nextNode = LRTA_Nav.LRTA_step((Tank)this, currentNode, true);
    } else
    {
      nextNode = selectFrontierNode();
    }
    if (path.isEmpty()) {

      if (nextNode != null) {
        computePath(nextNode);
      } else {
        println("No frontier found!");
        tankState = TankState.STOP;
      }
    }
    followPath();
  }

  void returnToBase() {
    // Still travelling home
    if  ( currentNode.type != NodeType.HOME_BASE )
    {

      if (goalNode == null)
      {
        goalNode = getNearestBaseNode();
      }

      if (path.isEmpty())
        /*  if (nav_Imp == Nav_Imp.LRTA)
         {
         Node nextNode = null;
         println("goalNode is " + goalNode.row + " " + goalNode.col);
         nextNode = LRTA_Nav.LRTA_step((Tank)this, currentNode, false);
         if (nextNode != null) {
         computePath(nextNode);
         } else {
         println("No goalNode found!");
         tankState = TankState.STOP;
         }
         } else
         {
         
         } */
        computePathToNearestBase();
      followPath();
      return;
    }
    if  ( currentNode.type == NodeType.HOME_BASE && !worldSensor.isMoreThanHalfInsideABase(team.id, this))
    {
      PVector dir = worldSensor.getBaseDirection(team.id, this);

      dir.mult(maxSpeed);
      velocity = dir;
      return;
    } else if (worldSensor.isMoreThanHalfInsideABase(team.id, this))
    {
      stopMoving();
      reportWaitFrames++;
    }


    if (reportWaitFrames >= REPORT_WAIT_DURATION) {
      // Report complete — resume patrol
      println("Report Completed");
      reportWaitFrames = 0;
      path.clear();
      goalNode = null;
      tankState = TankState.SEARCH;
    }
  }

  void computePathToNearestBase() {
    Node nearestBase = getNearestBaseNode();
    if (nearestBase != null) {
      computePathToNode(nearestBase);
    } else {
      path.clear();
    }
  }

  Node getNearestBaseNode() {
    return getNearestNodeOfType(NodeType.HOME_BASE);
  }

  Node getNearestNodeOfType(NodeType goalType) {
    if (currentNode == null) return null;

    HashMap<Node, Float> costSoFar = new HashMap<Node, Float>();
    ArrayList<Node> touched = new ArrayList<Node>();
    ArrayList<Node> queue = new ArrayList<Node>();

    currentNode.parent = null;
    costSoFar.put(currentNode, 0.0f);
    touched.add(currentNode);
    queue.add(currentNode);

    Node nearestGoal = null;
    float nearestCost = Float.MAX_VALUE;

    while (!queue.isEmpty()) {
      // Sort by accumulated cost, lowest first (Dijkstra)
      queue.sort((a, b) -> Float.compare(costSoFar.get(a), costSoFar.get(b)));
      Node current = queue.remove(0);

      if (current.type == goalType && current != currentNode) {
        float currentCost = costSoFar.get(current);
        if (currentCost < nearestCost) {
          nearestCost = currentCost;
          nearestGoal = current;
        }

        break;
      }

      for (Node nb : current.neighbors) {
        if (!nb.isTraversable()) continue;
        if (nb.exploredState == ExploredState.UNEXPLORED) continue;

        float stepCost = dist(current.position.x, current.position.y,
          nb.position.x, nb.position.y);
        float newCost = costSoFar.get(current) + stepCost;

        if (!costSoFar.containsKey(nb) || newCost < costSoFar.get(nb)) {
          costSoFar.put(nb, newCost);
          nb.parent = current;
          if (!touched.contains(nb)) {
            touched.add(nb);
            queue.add(nb);
          }
        }
      }
    }

    for (Node n : touched) {
      n.parent = null;
    }

    return nearestGoal;
  }

  void computePathToNode(Node targetNode) {
    path.clear();
    if (currentNode == null || targetNode == null) return;

    HashMap<Node, Float> costSoFar = new HashMap<Node, Float>();
    ArrayList<Node> touched = new ArrayList<Node>();
    ArrayList<Node> queue = new ArrayList<Node>();

    currentNode.parent = null;
    costSoFar.put(currentNode, 0.0f);
    touched.add(currentNode);
    queue.add(currentNode);

    boolean found = false;

    while (!queue.isEmpty()) {
      // Sort by accumulated cost, lowest first (Dijkstra)
      queue.sort((a, b) -> Float.compare(costSoFar.get(a), costSoFar.get(b)));
      Node current = queue.remove(0);

      if (current == targetNode) {
        found = true;
        goalNode = targetNode;
        break;
      }

      for (Node nb : current.neighbors) {
        if (!nb.isTraversable()) continue;
        if (nb.exploredState == ExploredState.UNEXPLORED) continue;

        float stepCost = dist(current.position.x, current.position.y,
          nb.position.x, nb.position.y);
        float newCost = costSoFar.get(current) + stepCost;

        if (!costSoFar.containsKey(nb) || newCost < costSoFar.get(nb)) {
          costSoFar.put(nb, newCost);
          nb.parent = current;
          if (!touched.contains(nb)) {
            touched.add(nb);
            queue.add(nb);
          }
        }
      }
    }

    // Reconstruct path if target was found
    if (found) {
      Node step = targetNode;
      while (step != null && step != currentNode) {
        path.add(0, step);
        step = step.parent;
      }
    }

    for (Node n : touched) {
      n.parent = null;
    }
  }

  void computePathTo(NodeType goalType) {
    Node targetNode = getNearestNodeOfType(goalType);
    if (targetNode != null) {
      computePathToNode(targetNode);
    } else {
      path.clear();
    }
  }

 /**
 Expanderar den nuvarande noden genom att uppfatta dess grannar i 8 riktningar.
 Lägger till nya grannar i tankens kunskapskarta (knownMap). De nya noderna markeras som VISIBLE
 och bildar frontieren, detta är som Russel och Norvig (2021, kap. 3.3) beskriver, de noder som nåtss men ännu inte
 expanderats.

 Detta är perceptionssteget i online-sökningen, efter varje steg tar tanken emot en persept och
 uppdaterar sin uppfattning om miljön (Russel & Norvig, kap. 4.5.2).
 */
  void perceiveNeighbours() {
    if (currentNode == null) return;

    int[] colDirections = {-1, -1, -1, 0, 0, 1, 1, 1};
    int[] rowDirections = {-1, 0, 1, -1, 1, -1, 0, 1};

    for (int i = 0; i < 8; i++) {
      int nodeCol = currentNode.col + colDirections[i];
      int nodeRow = currentNode.row + rowDirections[i];
      String key = getPositionKey(nodeCol, nodeRow);

      // Behandlar bara noder som inte redan lagts till i kunskapskartan
      if (!knownMap.containsKey(key)) {
        // Fråga världen vad som finns på possitionen av den kommande nya grannen (sensor)
        NodeType sensedType = worldSensor.senseTypeAt(nodeCol, nodeRow);

        float positionX = nodeCol * cellSize + cellSize;
        float posiitonY = nodeRow * cellSize + cellSize;
        Node newNode = new Node(nodeCol, nodeRow, positionX, posiitonY);
        newNode.type = sensedType;

        // Markera som nya noden som VISIBLE, den är känd men har inte expanderats, frontier-nod
        newNode.exploredState = ExploredState.VISIBLE;

        knownMap.put(key, newNode);
        wireNeighbours(newNode);

        // Beräkna antal nodsteg till hembasen via bakåtriktad BFS, denna information
        // används senare av hueristiken i selectFrontierNode() och computePath().
        computeDistanceFromBase(newNode);
      }
    }
  }

  void wireNeighbours(Node n) {
    int[] colDirections = {-1, -1, -1, 0, 0, 1, 1, 1};
    int[] rowDirections = {-1, 0, 1, -1, 1, -1, 0, 1};

    for (int i = 0; i < 8; i++) {
      String key = getPositionKey(n.col + colDirections[i], n.row + rowDirections[i]);
      if (knownMap.containsKey(key)) {
        Node nb = knownMap.get(key);
        if (!n.neighbors.contains(nb)) n.neighbors.add(nb);
        if (!nb.neighbors.contains((n))) nb.neighbors.add(n);
      }
    }
  }

  // Bakåtriktad BFS från hembasen till målet
  void computeDistanceFromBase(Node target) {
    ArrayList<Node> queue = new ArrayList<Node>();
    HashMap<Node, Integer> dist = new HashMap<Node, Integer>();

    for (Node n : knownMap.values()) {
      if (n.type == NodeType.HOME_BASE) {
        dist.put(n, 0);
        queue.add(n);
      }
    }

    while (!queue.isEmpty()) {
      Node current = queue.remove(0);
      if (current == target) {
        target.distanceFromBase = dist.get(current);
        return;
      }
      for (Node nb : current.neighbors) {
        if (!dist.containsKey(nb) && nb.isTraversable()) {
          dist.put(nb, dist.get(current) + 1);
          queue.add(nb);
        }
      }
    }
  }

  /**
  Väljer den mest lovande frontier-noden (VISIBLE nod) utefter heurestik som nästa mål
  att ta sig till.

  Alla VISIBLE noder i knownMap är kandidater, dessa representerar frontieren ,gränsen mellan
  utforskat och outforskat område (Russel & Norvig, 2021, kap. 3.3)

  Valet görs girigt med en heuristisk poängfunktion, kandidaten med lägst
  poäng väljs. Heuristiken uppmuntrar tanken att utforska noder nära sig själv
  och nära hembasen, och jobba sig systematiskt utåt

  @return bästa frontier-noden, eller null om frontiern är tom (utforskning klar)
  */
  Node selectFrontierNode() {
    ArrayList<Node> candidates = new ArrayList<Node>();

    for (Node n : knownMap.values()) {
      if (!n.isTraversable()) continue;
      // Endast frontier-noder (VISIBLE = nådda men ej expanderade)
      if (n.exploredState != ExploredState.VISIBLE) continue;
      candidates.add(n);
    }

    if (candidates.isEmpty()) return null;

    Node bestNode = null;
    float bestScore = Float.MAX_VALUE;

    for (Node n : candidates) {
      float score = 0;

      // Undiv att utforska hembasen
      if (n.type == NodeType.HOME_BASE) {
        score += 20000;
      } else {
        // Föredra noder nära hembasen, uforska succesivt utåt från basen
        score += n.distanceFromBase * 150;
      }

      // Föredra noder som ligger nära tankens nuvarande position, undviker onödigt långa hopp.
      score += dist(position.x, position.y, n.position.x, n.position.y);

      // Undivk noder som tanken tidigare haft svårighet att ta sig till, skett kollision på vägen dit
      if (n.exploredState == ExploredState.PENDING) score += 3000;

      if (score < bestScore) {
        bestScore = score;
        bestNode  = n;
      }
    }
    return bestNode;
  }

  /**
  Beräknar en väg från currentNode till goalNode med Greedy Best-First Search.

  Greedy Best-First Search utvärderar noder med enbart en heuristisk uppskattning
  f(n) = h(n), utan ackumulerad vägkostnad g(n).
  Heurestiken är utformad för utforskning snarare än kortaste vägen, den planerar vägen med föredragna noder som
  inte har besökts men som är kända nära hembasen.

  Den beräknade vgen lagras i path som en ordnad lista av noder från currentNode till goalNode, denna path följs
  sedan med followPath().

  @param goalNode målnoden vald av selectFrontierNode()
  */
  void computePath(Node goalNode) {
    path.clear();
    if (currentNode == null || goalNode == null) return;

    ArrayList<Node> touched = new ArrayList<Node>();
    ArrayList<Node> queue   = new ArrayList<Node>();

    currentNode.hCost   = 0;
    currentNode.visited = true;
    currentNode.parent  = null;
    touched.add(currentNode);
    queue.add(currentNode);

    boolean found = false;

    while (!queue.isEmpty()) {
      // Expandera alltid noden med lägst heurestiskt värde först
      queue.sort((a, b) -> Float.compare(a.hCost, b.hCost));
      Node current = queue.remove(0);

      if (current == goalNode) {
        found = true;
        break;
      }

      for (Node nb : current.neighbors) {
        if (nb.visited) continue;
        if (!nb.isTraversable()) continue;

        // h(n), enbart heuristik och ingen ackumulerad kostnad g(n) 
        float h = 0;

        // Undvik att gå igenom hembasen
        if (nb.type == NodeType.HOME_BASE) {
          h += 10000;
        } else {
          // föredra noder som är nära basen
          h -= nb.distanceFromBase * 150;
        }

        // Undvik i första hand noder som tanken haft svårt att ta sig till tidigare, kollisionssvårigheter
        if (nb.exploredState == ExploredState.PENDING) h += 5000;
        // Undvik helst redan besökta noder
        if (nb.exploredState == ExploredState.VISITED) h += 2000;
        // Undvik att direkt backa tillbaka vägen tanken kom ifrån
        if (nb == lastNode) h += 500;

        // Föredra noder som är nära tankens nuvarande position, detta får tanken att
        // fördra åka vertikalt eller horisontelt istället för diagonalt om inte diagonalt är den optimala vägen
        h += dist(position.x, position.y, nb.position.x, nb.position.y) * 150;

        nb.hCost  = h;
        nb.parent = current;
        nb.visited = true;
        touched.add(nb);
        queue.add(nb);
      }
    }

    // Rekonstruera vägen genom att följa parent-pekare från mål tillbaka till start
    if (found) {
      Node step = goalNode;
      while (step != null && step != currentNode) {
        path.add(0, step);
        step = step.parent;
      }
    }

    // Återställ flaggor, knownMap är persistent och måste rensas efter varje sökning
    for (Node n : touched) {
      n.visited = false;
      n.parent  = null;
    }
  }

  void followPath() {
    if (path.isEmpty()) return;
    targetNode = path.get(0);

    seek();

    if (isAtTarget()) {
      path.remove(0);

      targetNode = path.isEmpty() ? null : path.get(0);
    }
  }

  void onCollisionDetected(Sprite hitObject) {
    if (active) {

      PVector normal = PVector.sub(this.position, hitObject.position);
      normal.normalize();

      float dotProduct = velocity.dot(normal);

      // Only bounce if moving TOWARD the object (prevents getting stuck inside)
      if (dotProduct < 0) {
        PVector reflection = PVector.mult(normal, 2 * dotProduct);
        velocity.sub(reflection);
      }

      if (targetNode != null && path.size() > 0) {


        if (nav_Imp == Nav_Imp.LRTA)
        {
          path.get(0).exploredState = ExploredState.VISITED;
          LRTA_Nav.handleCollision(path.get(0));
        } else
        {
          path.get(0).exploredState = ExploredState.PENDING;
        }

        path.clear(); // Replan
      }
      position.add(PVector.mult(normal, 2));
    }
  }

  void onBoundaryCollisionDetected() {
    velocity.mult(-1);

    //energy loss
    velocity.mult(0.8);

    position.add(PVector.mult(velocity, 2));
  }


  boolean enemyInSight() {
    return worldSensor.senseEnemyInRay(
      position.x, position.y,
      this.velocity.heading(), rayLength, rayWidth,
      team.getId()
      );
  }

  //boolean tankInSight() {
  //  return worldSensor.senseTank(this,
  //    position.x, position.y,
  //    this.velocity.heading(), rayLength, rayWidth
  //    );
  //}


  void seek() {
    PVector desired = PVector.sub(targetNode.position, this.position);
    desired.setMag(this.maxSpeed);
    PVector steer = PVector.sub(desired, this.velocity);
    steer.limit(turnStep);
    this.applyForce(steer);
  }

  void applyForce(PVector force) {

    this.acceleration.add(force);
  }


  void updatePosition() {
    this.velocity.add(this.acceleration);
    this.velocity.limit(this.maxSpeed);
    float turnAmount = 0.001;
    velocity.mult(1.0 - constrain(turnAmount, 0, 0.7));
    this.position.add(this.velocity);
    this.acceleration.mult(0);

    // println("Speed:" + velocity.mag());
  }




  boolean isAtTarget() {
    if (targetNode == null) return false;
    return position.dist(targetNode.position) < radius; // within 5 pixels
  }


  void stopMoving() {
    velocity.mult(0);
    acceleration.mult(0);
  }



  //======================================
  void drawTank(float x, float y) {
    fill(this.col, 50);

    ellipse(x, y, 50, 50);
    strokeWeight(1);
    line(x, y, x+25, y);

    //kanontornet
    ellipse(0, 0, 25, 25);
    strokeWeight(3);
    float cannon_length = this.diameter/2;
    line(0, 0, cannon_length, 0);
  }

  void display() {
    fill(this.col);
    strokeWeight(1);

    pushMatrix();

    translate(this.position.x, this.position.y);

    imageMode(CENTER);

    rotate(this.velocity.heading());
    drawTank(0, 0);
    imageMode(CORNER);
    strokeWeight(1);

    popMatrix();
  }

  void displaySightRay() {
    PVector rayDir  = new PVector(cos(this.velocity.heading()), sin(this.velocity.heading()));
    PVector perp    = new PVector(-sin(this.velocity.heading()), cos(this.velocity.heading()));

    // Ray tip
    float tipX = position.x + rayDir.x * rayLength;
    float tipY = position.y + rayDir.y * rayLength;

    // Colour changes when an enemy is detected
    boolean hit = enemyInSight();

    pushStyle();
    // Corridor sides
    stroke(hit ? color(255, 50, 50, 180) : color(255, 220, 0, 100));
    strokeWeight(1);
    noFill();

    // Left side of corridor
    line(position.x + perp.x * rayWidth, position.y + perp.y * rayWidth,
      tipX        + perp.x * rayWidth, tipY        + perp.y * rayWidth);

    // Right side of corridor
    line(position.x - perp.x * rayWidth, position.y - perp.y * rayWidth,
      tipX        - perp.x * rayWidth, tipY        - perp.y * rayWidth);

    // Cap at the end
    line(tipX + perp.x * rayWidth, tipY + perp.y * rayWidth,
      tipX - perp.x * rayWidth, tipY - perp.y * rayWidth);

    // Centre line
    stroke(hit ? color(255, 50, 50, 220) : color(255, 220, 0, 180));
    strokeWeight(1.5);
    line(position.x, position.y, tipX, tipY);

    // Filled corridor — semi-transparent
    fill(hit ? color(255, 50, 50, 50) : color(255, 220, 0, 40));
    noStroke();
    beginShape();
    vertex(position.x + perp.x * rayWidth, position.y + perp.y * rayWidth);
    vertex(tipX        + perp.x * rayWidth, tipY        + perp.y * rayWidth);
    vertex(tipX        - perp.x * rayWidth, tipY        - perp.y * rayWidth);
    vertex(position.x  - perp.x * rayWidth, position.y  - perp.y * rayWidth);
    endShape(CLOSE);
    popStyle();
  }

  void displayPath() {
    if (path.isEmpty()) return;
    pushStyle();

    // Draw all path nodes
    for (int i = 0; i < path.size(); i++) {
      Node n = path.get(i);

      if (i == path.size() - 1) {
        // Goal node — distinct colour
        fill(255, 80, 80, 200);
      } else {
        // Intermediate path nodes
        fill(80, 180, 255, 160);
      }
      ellipse(n.position.x, n.position.y, n.w * 3, n.h * 3);
    }

    // Draw the current target node (next step) on top
    if (targetNode != null) {
      fill(255, 200, 0, 200);
      ellipse(targetNode.position.x, targetNode.position.y, targetNode.w * 3, targetNode.h * 3);
    }
    popStyle();
  }

  void displayKnownMap() {
    for (Node n : knownMap.values()) {
      fill(n.getColor());
      ellipse(n.position.x, n.position.y, n.w, n.h);

      //show  node's heuristic value
      if (nav_Imp == Nav_Imp.LRTA) {
        float hValue = LRTA_Nav.H.getOrDefault(n, 0.0f);
        if (hValue > 0) {
          push();
          fill(0);
          textAlign(CENTER, CENTER);
          textSize(15);
          text(String.format("%.1f", hValue), n.position.x, n.position.y-10);
          pop();
        }
      }
    }
  }



  String getPositionKey(int column, int row) {
    return column + "," + row;
  }

  int worldToCol(float positionX) {
    return (int)round((positionX - cellSize) / cellSize);
  }

  int worldToRow(float positionY) {
    return (int)round((positionY - cellSize) / cellSize);
  }

  Node nearestKnownNode(PVector pos) {
    Node bestNode = null;
    float bestDist = Float.MAX_VALUE;
    for (Node n : knownMap.values()) {
      float d = dist(pos.x, pos.y, n.position.x, n.position.y);
      if (d < bestDist) {
        bestDist = d;
        bestNode = n;
      }
    }
    return bestNode;
  }

  int getId() {
    return tank_id;
  }
}
